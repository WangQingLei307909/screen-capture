//
//  AppDelegate.m
//  VTAntiScreenCapture
//
//  Created by abox on 2021/3/18.
//  Copyright © 2021 wql. All rights reserved.
//

#import "AppDelegate.h"
#import "TestViewController.h"
@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.window.rootViewController = [[UINavigationController alloc]initWithRootViewController:[[TestViewController alloc]init]];
    return YES;
}



@end
