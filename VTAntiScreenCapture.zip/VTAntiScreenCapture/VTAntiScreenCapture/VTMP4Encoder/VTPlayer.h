//
//  VTPlayer.h
//  AFNetworking
//
//  Created by 俞伟山 on 2019/1/1.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// 简单播放器
@interface VTPlayer : NSObject

@end

NS_ASSUME_NONNULL_END
