//
//  UIView+antiCapture.m
//  AFNetworking
//
//  Created by 俞伟山 on 2019/1/1.
//

#import "UIView+antiCapture.h"

@implementation UIView (antiCapture)

@end
