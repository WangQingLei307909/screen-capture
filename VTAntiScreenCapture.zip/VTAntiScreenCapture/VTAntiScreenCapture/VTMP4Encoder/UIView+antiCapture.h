//
//  UIView+antiCapture.h
//  AFNetworking
//
//  Created by 俞伟山 on 2019/1/1.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIView (antiCapture)

@end

NS_ASSUME_NONNULL_END
