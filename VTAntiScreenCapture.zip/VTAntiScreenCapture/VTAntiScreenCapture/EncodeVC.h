//
//  EncodeVC.h
//  VTAntiScreenCapture
//
//  Created by abox on 2021/3/18.
//  Copyright © 2021 wql. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface EncodeVC : UIViewController

@end

NS_ASSUME_NONNULL_END
