//
//  EncodeVC.m
//  VTAntiScreenCapture
//
//  Created by abox on 2021/3/18.
//  Copyright © 2021 wql. All rights reserved.
//

#import "EncodeVC.h"
#import "VTMP4Encoder.h"
@interface EncodeVC ()
@property (weak, nonatomic) IBOutlet UILabel *label;

@end

@implementation EncodeVC
- (IBAction)mp4Action:(id)sender {
    [VTMP4Encoder encodeViewToMP4:self.label completion:^(NSData *data) {
        NSLog(@"data: %@", data);
    }];
}

- (void)viewDidLoad {
    [super viewDidLoad];

}

@end
