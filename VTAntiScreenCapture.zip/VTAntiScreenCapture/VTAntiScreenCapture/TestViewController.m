//
//  TestViewController.m
//  VTAntiScreenCapture
//
//  Created by abox on 2021/3/18.
//  Copyright © 2021 wql. All rights reserved.
//

#import "TestViewController.h"
#import "SimpleDRMVC.h"
#import "EncodeVC.h"
@interface TestViewController ()

@end

@implementation TestViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (IBAction)demoAction:(id)sender {
    [self.navigationController pushViewController:[[SimpleDRMVC alloc] init] animated:YES];
}

- (IBAction)mp4Action:(id)sender {
    [self.navigationController pushViewController:[[EncodeVC alloc] init] animated:YES];
}

@end
