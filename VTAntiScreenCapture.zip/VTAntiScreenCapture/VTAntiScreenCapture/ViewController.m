//
//  ViewController.m
//  VTAntiScreenCapture
//
//  Created by abox on 2021/3/18.
//  Copyright © 2021 wql. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
- (IBAction)demoAction:(id)sender {
}
- (IBAction)mp4Action:(id)sender {
}

- (void)viewDidLoad {
    [super viewDidLoad];
}


@end
